from django.shortcuts import render, redirect
from django.db import connection
from django.contrib import messages
from django.contrib.auth.decorators import login_required

def dictfetchall(cursor):
    """Mengubah hasil query cursor menjadi list of dictionary agar mudah diakses di template."""
    columns = [col[0] for col in cursor.description]
    return [dict(zip(columns, row)) for row in cursor.fetchall()]

# ==========================================
# VIEWS UNTUK ORDER
# ==========================================

@login_required
def create_order(request):
    """Halaman Checkout / Beli Tiket"""
    if request.method == 'POST':
        # Contoh logika POST: Ambil data dari form create_order.html
        customer_id = request.session.get('user_id') # Sesuaikan cara ambil ID user/customer kamu
        ticket_id = request.POST.get('selected_cat_id')
        promo_id = request.POST.get('promo_id') # Jika ada input promo
        
        try:
            with connection.cursor() as cursor:
                cursor.execute("SET search_path TO tiktaktuk")
                # Logika Insert Order dan Order_Promotion di sini
                # Trigger validasi promo akan otomatis jalan di DB saat insert ke ORDER_PROMOTION
                messages.success(request, "Pesanan berhasil dibuat!")
                return redirect('read_order_cust')
        except Exception as e:
            messages.error(request, f"Gagal membuat pesanan: {str(e)}")

    # Untuk GET: Ambil data kategori tiket dsb untuk ditampilkan di form
    return render(request, 'create_order.html')

@login_required
def read_order_admin(request):
    """Admin melihat seluruh order yang ada di sistem"""
    with connection.cursor() as cursor:
        cursor.execute("SET search_path TO tiktaktuk")
        cursor.execute("""
            SELECT o.order_id, o.order_date, o.total_price, o.status, c.full_name 
            FROM "ORDER" o
            JOIN CUSTOMER c ON o.customer_id = c.customer_id
            ORDER BY o.order_date DESC
        """)
        orders = dictfetchall(cursor)
    return render(request, 'read_order_admin.html', {'orders': orders})

@login_required
def read_order_cust(request):
    """Customer melihat riwayat pesanannya sendiri"""
    user_id = request.session.get('user_id') # Sesuaikan dengan session login kamu
    with connection.cursor() as cursor:
        cursor.execute("SET search_path TO tiktaktuk")
        cursor.execute("""
            SELECT o.* FROM "ORDER" o
            JOIN CUSTOMER c ON o.customer_id = c.customer_id
            WHERE c.user_id = %s
            ORDER BY o.order_date DESC
        """, [user_id])
        orders = dictfetchall(cursor)
    return render(request, 'read_order_cust.html', {'orders': orders})

@login_required
def read_order_organizer(request):
    """Organizer melihat order yang masuk untuk event milik mereka"""
    user_id = request.session.get('user_id')
    with connection.cursor() as cursor:
        cursor.execute("SET search_path TO tiktaktuk")
        cursor.execute("""
            SELECT o.*, c.full_name 
            FROM "ORDER" o
            JOIN CUSTOMER c ON o.customer_id = c.customer_id
            -- Logic join ke EVENT dan ORGANIZER disesuaikan skema kamu
            ORDER BY o.order_date DESC
        """)
        orders = dictfetchall(cursor)
    return render(request, 'read_order_organizer.html', {'orders': orders})


# ==========================================
# VIEWS UNTUK PROMO
# ==========================================

@login_required
def crud_promo_admin(request):
    """Manajemen Promo oleh Admin (View, Create, Update, Delete)"""
    with connection.cursor() as cursor:
        cursor.execute("SET search_path TO tiktaktuk")
        
        if request.method == 'POST':
            # Contoh logic Delete
            if 'delete_id' in request.POST:
                cursor.execute("DELETE FROM PROMOTION WHERE promotion_id = %s", [request.POST.get('delete_id')])
            # Tambahkan logic Create/Update di sini
            return redirect('crud_promo_admin')

        cursor.execute("SELECT * FROM PROMOTION ORDER BY start_date DESC")
        promos = dictfetchall(cursor)
    return render(request, 'CRUD_promo_admin.html', {'promos': promos})

@login_required
def read_promo_cust(request):
    """Daftar promo yang bisa dilihat oleh Customer"""
    with connection.cursor() as cursor:
        cursor.execute("SET search_path TO tiktaktuk")
        cursor.execute("SELECT * FROM PROMOTION WHERE end_date >= CURRENT_DATE")
        promos = dictfetchall(cursor)
    return render(request, 'read_promo_cust.html', {'promos': promos})

@login_required
def read_promo_organizer(request):
    """Daftar promo untuk sisi Organizer"""
    with connection.cursor() as cursor:
        cursor.execute("SET search_path TO tiktaktuk")
        cursor.execute("SELECT * FROM PROMOTION")
        promos = dictfetchall(cursor)
    return render(request, 'read_promo_organizer.html', {'promos': promos})

def read_promo_guest(request):
    """Daftar promo untuk Guest (Tanpa Login)"""
    with connection.cursor() as cursor:
        cursor.execute("SET search_path TO tiktaktuk")
        cursor.execute("SELECT * FROM PROMOTION WHERE end_date >= CURRENT_DATE")
        promos = dictfetchall(cursor)
    return render(request, 'read_promo_guest.html', {'promos': promos})