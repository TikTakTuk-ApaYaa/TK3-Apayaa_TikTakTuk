from django.urls import path
from . import views

# Sesuaikan app_name jika kamu menggunakan namespacing di Django
app_name = 'fitur_biru' 

urlpatterns = [
    # ==========================================
    # URLS UNTUK FITUR ORDER (PESANAN)
    # ==========================================
    
    # Halaman Form Pembuatan Order / Checkout Tiket
    path('order/create/', views.create_order, name='create_order'),
    
    # Halaman Riwayat Pesanan Saya (Akses: Customer)
    path('order/my-orders/', views.read_order_cust, name='read_order_cust'),
    
    # Halaman Laporan Order Masuk (Akses: Organizer)
    path('order/organizer-dashboard/', views.read_order_organizer, name='read_order_organizer'),
    
    # Halaman Manajemen Semua Order (Akses: Admin)
    path('order/admin-manage/', views.read_order_admin, name='read_order_admin'),


    # ==========================================
    # URLS UNTUK FITUR PROMO
    # ==========================================
    
    # Halaman CRUD Promo (Akses: Admin)
    path('promo/manage/', views.crud_promo_admin, name='crud_promo_admin'),
    
    # Halaman Daftar Promo untuk Pengguna Terdaftar (Akses: Customer)
    path('promo/list/', views.read_promo_cust, name='read_promo_cust'),
    
    # Halaman Daftar Promo untuk Penyelenggara (Akses: Organizer)
    path('promo/organizer-list/', views.read_promo_organizer, name='read_promo_organizer'),
    
    # Halaman Daftar Promo untuk Pengunjung Umum (Tanpa Login)
    path('promo/explore/', views.read_promo_guest, name='read_promo_guest'),
]